package com.nova.messenger.data

import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.rpc
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** Все полномочия проверяются повторно на сервере в SECURITY DEFINER RPC. */
class OwnerRepo(private val client: SupabaseClient) {
    suspend fun searchUsers(query: String): List<OwnerUser> =
        client.postgrest.rpc("nova_admin_search_users", buildJsonObject { put("q", query.trim()) })
            .decodeList<OwnerUser>()

    suspend fun grantPremium(userId: String, days: Int) {
        client.postgrest.rpc("nova_admin_grant_premium", buildJsonObject {
            put("target_user", userId); put("days", days)
        })
    }

    suspend fun adjustStars(userId: String, delta: Long): Long =
        client.postgrest.rpc("nova_admin_adjust_stars", buildJsonObject {
            put("target_user", userId); put("delta", delta)
        }).decodeAs<Long>()

    suspend fun setAdmin(userId: String, enabled: Boolean) {
        client.postgrest.rpc("nova_owner_set_admin", buildJsonObject {
            put("target_user", userId); put("make_admin", enabled)
        })
    }

    suspend fun reports(): List<OwnerReport> =
        client.postgrest.rpc("nova_admin_list_reports").decodeList<OwnerReport>()

    suspend fun updateReport(id: Long, status: String) {
        client.postgrest.rpc("nova_admin_update_report", buildJsonObject {
            put("report_id", id); put("new_status", status)
        })
    }

    suspend fun audit(): List<OwnerAudit> =
        client.postgrest.rpc("nova_owner_audit").decodeList<OwnerAudit>()
}
