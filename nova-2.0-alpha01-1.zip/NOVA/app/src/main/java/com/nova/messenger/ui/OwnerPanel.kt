package com.nova.messenger.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.nova.messenger.data.Graph
import com.nova.messenger.data.OwnerUser
import kotlinx.coroutines.launch

@Composable
fun OwnerPanelScreen(nav: NavHostController) {
    val me by Graph.chats.me.collectAsState()
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var users by remember { mutableStateOf<List<OwnerUser>>(emptyList()) }
    var reports by remember { mutableStateOf(emptyList<com.nova.messenger.data.OwnerReport>()) }
    var audit by remember { mutableStateOf(emptyList<com.nova.messenger.data.OwnerAudit>()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf("users") }

    fun reload() {
        scope.launch {
            loading = true
            runCatching {
                when (selected) {
                    "reports" -> reports = Graph.owner.reports()
                    "audit" -> audit = Graph.owner.audit()
                    else -> users = Graph.owner.searchUsers(query)
                }
            }.onFailure { message = it.message ?: "Не удалось загрузить данные" }
            loading = false
        }
    }

    LaunchedEffect(selected) { reload() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Меню владельца", onBack = { nav.popBackStack() })
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (me?.isOwner != true) {
                Text("Доступ запрещён. Панель доступна только владельцу NOVA.", color = MaterialTheme.colorScheme.error)
                return@Column
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.AdminPanelSettings, null, tint = Cyan, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("NOVA Control Center", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Управление сервером · действия записываются в журнал", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected == "users", { selected = "users" }, { Text("Пользователи") })
                FilterChip(selected == "reports", { selected = "reports" }, { Text("Жалобы") })
                FilterChip(selected == "audit", { selected = "audit" }, { Text("Журнал") })
            }
            when (selected) {
                "users" -> {
                    OutlinedTextField(query, { query = it; }, Modifier.fillMaxWidth(), label = { Text("Поиск по имени или @username") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { reload() }, enabled = !loading) { Text("Найти") }
                        OutlinedButton(onClick = { query = ""; reload() }) { Text("Все") }
                    }
                    users.forEach { user -> OwnerUserCard(user, me?.isOwner == true, onAction = { action ->
                        scope.launch {
                            runCatching {
                                when (action) {
                                    "premium30" -> Graph.owner.grantPremium(user.id, 30)
                                    "premium90" -> Graph.owner.grantPremium(user.id, 90)
                                    "stars100" -> Graph.owner.adjustStars(user.id, 100)
                                    "stars-100" -> Graph.owner.adjustStars(user.id, -100)
                                    "admin" -> Graph.owner.setAdmin(user.id, true)
                                    "removeAdmin" -> Graph.owner.setAdmin(user.id, false)
                                }
                                message = "Действие выполнено для @${user.username}"
                                users = Graph.owner.searchUsers(query)
                            }.onFailure { message = it.message ?: "Ошибка операции" }
                        }
                    }) }
                    if (users.isEmpty() && !loading) Text("Пользователи не найдены", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                "reports" -> {
                    Text("Проверяются только сообщения, на которые пожаловались. Полная история личных чатов владельцу не открывается.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    reports.forEach { report ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Жалоба #${report.id} · ${report.reason}", fontWeight = FontWeight.Bold)
                                Text("От @${report.reporterUsername} на сообщение @${report.messageSenderUsername}", fontSize = 12.sp)
                                Text(report.messageBody)
                                if (report.details.isNotBlank()) Text(report.details, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { scope.launch { runCatching { Graph.owner.updateReport(report.id, "resolved"); reports = Graph.owner.reports() }.onFailure { message = it.message } } }) { Text("Решено") }
                                    TextButton(onClick = { scope.launch { runCatching { Graph.owner.updateReport(report.id, "dismissed"); reports = Graph.owner.reports() }.onFailure { message = it.message } } }) { Text("Отклонить") }
                                }
                            }
                        }
                    }
                    if (reports.isEmpty() && !loading) Text("Открытых жалоб нет")
                }
                else -> {
                    audit.forEach { entry ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(entry.action, fontWeight = FontWeight.Bold)
                                Text("Исполнитель: @${entry.actorUsername} · Цель: ${entry.targetUsername?.let { "@$it" } ?: "—"}", fontSize = 12.sp)
                                Text(entry.details.toString(), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(entry.createdAt, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (audit.isEmpty() && !loading) Text("Записей пока нет")
                }
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            message?.let { Text(it, color = Cyan, fontSize = 13.sp) }
            Text("Все привилегированные операции проверяются сервером Supabase. Назначение и снятие администраторов доступно только владельцу.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OwnerUserCard(user: OwnerUser, isOwner: Boolean, onAction: (String) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(user.displayName.ifBlank { user.username }, fontWeight = FontWeight.Bold)
                    Text("@${user.username} · ${user.id.take(8)}…", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (user.isOwner) Text("ВЛАДЕЛЕЦ", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                else if (user.adminRole != null) Text(user.adminRole.uppercase(), color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Text("Premium: ${if (user.isPremium) "активен" else "нет"} · Звёзды: ${user.stars}", fontSize = 12.sp)
            if (!user.isOwner) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { onAction("premium30") }) { Text("Premium 30 дн.") }
                    TextButton(onClick = { onAction("premium90") }) { Text("90 дн.") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { onAction("stars100") }) { Text("+100 ⭐") }
                    TextButton(onClick = { onAction("stars-100") }) { Text("−100 ⭐") }
                }
                if (isOwner) {
                    if (user.adminRole == null) TextButton(onClick = { onAction("admin") }) { Text("Назначить администратором") }
                    else TextButton(onClick = { onAction("removeAdmin") }) { Text("Снять роль администратора") }
                }
            }
        }
    }
}
