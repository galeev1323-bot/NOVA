-- NOVA 2.0: server-enforced owner/admin tools.
-- Apply in Supabase SQL Editor after schema.sql and 20261107_owner_account.sql.

create table if not exists public.nova_admin_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','moderator')),
  granted_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.nova_admin_audit (
  id bigint generated always as identity primary key,
  actor_id uuid not null references auth.users(id),
  action text not null,
  target_user_id uuid references auth.users(id),
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.nova_wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  stars bigint not null default 0 check (stars >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.nova_message_reports (
  id bigint generated always as identity primary key,
  reporter_id uuid not null references auth.users(id),
  message_id uuid not null references public.messages(id) on delete cascade,
  reason text not null check (length(trim(reason)) between 3 and 80),
  details text not null default '' check (length(details) <= 1000),
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  reviewed_by uuid references auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  unique (reporter_id, message_id)
);

create or replace function public.nova_is_staff()
returns boolean language sql stable security definer
set search_path = public, pg_temp as $$
  select exists(select 1 from public.profiles p where p.id = auth.uid() and p.is_owner)
      or exists(select 1 from public.nova_admin_roles r where r.user_id = auth.uid())
$$;

create or replace function public.nova_admin_search_users(q text)
returns table(id uuid, username text, display_name text, is_premium boolean,
              premium_until timestamptz, is_owner boolean, created_at timestamptz,
              admin_role text, stars bigint)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  if not public.nova_is_staff() then raise exception 'not_authorized'; end if;
  return query
    select p.id, p.username, p.display_name, p.is_premium, p.premium_until, p.is_owner,
           p.created_at, r.role, coalesce(w.stars,0)
    from public.profiles p
    left join public.nova_admin_roles r on r.user_id = p.id
    left join public.nova_wallets w on w.user_id = p.id
    where coalesce(q,'') = '' or p.username ilike '%' || left(q,64) || '%'
       or p.display_name ilike '%' || left(q,64) || '%'
    order by p.created_at desc limit 30;
end $$;

create or replace function public.nova_admin_grant_premium(target_user uuid, days integer)
returns timestamptz language plpgsql security definer set search_path = public, pg_temp as $$
declare result_until timestamptz;
begin
  if not public.nova_is_staff() then raise exception 'not_authorized'; end if;
  if days < 1 or days > 36500 then raise exception 'invalid_days'; end if;
  if exists(select 1 from public.profiles where id=target_user and is_owner) then
    raise exception 'owner_is_protected';
  end if;
  update public.profiles set is_premium=true,
    premium_until = greatest(coalesce(premium_until, now()), now()) + make_interval(days => days)
    where id=target_user returning premium_until into result_until;
  if result_until is null then raise exception 'user_not_found'; end if;
  insert into public.nova_admin_audit(actor_id,action,target_user_id,details)
    values(auth.uid(),'grant_premium',target_user,jsonb_build_object('days',days,'premium_until',result_until));
  return result_until;
end $$;

create or replace function public.nova_admin_adjust_stars(target_user uuid, delta bigint)
returns bigint language plpgsql security definer set search_path = public, pg_temp as $$
declare new_balance bigint;
begin
  if not public.nova_is_staff() then raise exception 'not_authorized'; end if;
  if delta = 0 or delta < -100000 or delta > 100000 then raise exception 'invalid_delta'; end if;
  if not exists(select 1 from public.profiles where id=target_user) then raise exception 'user_not_found'; end if;
  insert into public.nova_wallets(user_id,stars) values(target_user,0)
    on conflict(user_id) do nothing;
  update public.nova_wallets set stars=stars+delta, updated_at=now()
    where user_id=target_user and stars+delta >= 0 returning stars into new_balance;
  if new_balance is null then raise exception 'insufficient_stars'; end if;
  insert into public.nova_admin_audit(actor_id,action,target_user_id,details)
    values(auth.uid(),'adjust_stars',target_user,jsonb_build_object('delta',delta,'balance',new_balance));
  return new_balance;
end $$;

create or replace function public.nova_owner_set_admin(target_user uuid, make_admin boolean)
returns void language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if not exists(select 1 from public.profiles where id=auth.uid() and is_owner) then
    raise exception 'owner_only';
  end if;
  if target_user=auth.uid() or exists(select 1 from public.profiles where id=target_user and is_owner) then
    raise exception 'owner_is_protected';
  end if;
  if not exists(select 1 from public.profiles where id=target_user) then raise exception 'user_not_found'; end if;
  if make_admin then
    insert into public.nova_admin_roles(user_id,role,granted_by) values(target_user,'admin',auth.uid())
      on conflict(user_id) do update set role='admin',granted_by=auth.uid();
  else
    delete from public.nova_admin_roles where user_id=target_user;
  end if;
  insert into public.nova_admin_audit(actor_id,action,target_user_id,details)
    values(auth.uid(),case when make_admin then 'grant_admin' else 'revoke_admin' end,target_user,'{}'::jsonb);
end $$;

create or replace function public.nova_submit_message_report(target_message uuid, report_reason text, report_details text default '')
returns bigint language plpgsql security definer set search_path = public, pg_temp as $$
declare new_id bigint;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if not exists(
    select 1 from public.messages m join public.chat_members cm on cm.chat_id=m.chat_id
    where m.id=target_message and cm.user_id=auth.uid() and m.sender_id<>auth.uid()
  ) then raise exception 'message_not_reportable'; end if;
  insert into public.nova_message_reports(reporter_id,message_id,reason,details)
    values(auth.uid(),target_message,trim(report_reason),coalesce(report_details,''))
    on conflict(reporter_id,message_id) do update set reason=excluded.reason,details=excluded.details,status='open'
    returning id into new_id;
  return new_id;
end $$;

create or replace function public.nova_admin_list_reports()
returns table(id bigint, reporter_username text, message_sender_username text,
              message_body text, reason text, details text, status text, created_at timestamptz)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  if not public.nova_is_staff() then raise exception 'not_authorized'; end if;
  -- Deliberately exposes only the exact message attached to a report, never the user's whole chat history.
  return query select r.id, rp.username, sp.username, coalesce(m.body,'[вложение]'),
      r.reason,r.details,r.status,r.created_at
    from public.nova_message_reports r
    join public.messages m on m.id=r.message_id
    join public.profiles rp on rp.id=r.reporter_id
    join public.profiles sp on sp.id=m.sender_id
    where r.status in ('open','reviewing') order by r.created_at asc limit 100;
end $$;

create or replace function public.nova_admin_update_report(report_id bigint, new_status text)
returns void language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if not public.nova_is_staff() then raise exception 'not_authorized'; end if;
  if new_status not in ('reviewing','resolved','dismissed') then raise exception 'invalid_status'; end if;
  update public.nova_message_reports set status=new_status, reviewed_by=auth.uid(), reviewed_at=now() where id=report_id;
  if not found then raise exception 'report_not_found'; end if;
  insert into public.nova_admin_audit(actor_id,action,details)
    values(auth.uid(),'update_report',jsonb_build_object('report_id',report_id,'status',new_status));
end $$;

create or replace function public.nova_owner_audit(limit_count integer default 30)
returns table(id bigint, actor_username text, action text, target_username text, details jsonb, created_at timestamptz)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  if not exists(select 1 from public.profiles where id=auth.uid() and is_owner) then raise exception 'owner_only'; end if;
  return query select a.id, ap.username, a.action, tp.username, a.details, a.created_at
    from public.nova_admin_audit a
    join public.profiles ap on ap.id=a.actor_id
    left join public.profiles tp on tp.id=a.target_user_id
    order by a.created_at desc limit greatest(1,least(limit_count,100));
end $$;

revoke all on public.nova_admin_roles, public.nova_admin_audit, public.nova_wallets, public.nova_message_reports from anon, authenticated;
revoke all on function public.nova_is_staff() from public, anon;
revoke all on function public.nova_admin_search_users(text) from public, anon;
revoke all on function public.nova_admin_grant_premium(uuid,integer) from public, anon;
revoke all on function public.nova_admin_adjust_stars(uuid,bigint) from public, anon;
revoke all on function public.nova_owner_set_admin(uuid,boolean) from public, anon;
revoke all on function public.nova_submit_message_report(uuid,text,text) from public, anon;
revoke all on function public.nova_admin_list_reports() from public, anon;
revoke all on function public.nova_admin_update_report(bigint,text) from public, anon;
revoke all on function public.nova_owner_audit(integer) from public, anon;
grant execute on function public.nova_admin_search_users(text) to authenticated;
grant execute on function public.nova_admin_grant_premium(uuid,integer) to authenticated;
grant execute on function public.nova_admin_adjust_stars(uuid,bigint) to authenticated;
grant execute on function public.nova_owner_set_admin(uuid,boolean) to authenticated;
grant execute on function public.nova_submit_message_report(uuid,text,text) to authenticated;
grant execute on function public.nova_admin_list_reports() to authenticated;
grant execute on function public.nova_admin_update_report(bigint,text) to authenticated;
grant execute on function public.nova_owner_audit(integer) to authenticated;
