-- NOVA: безопасное назначение владельца и бессрочного Premium.
-- Выполнить один раз в Supabase Dashboard -> SQL Editor.

alter table public.profiles
  add column if not exists is_owner boolean not null default false;

-- Владельцу разрешены Premium-косметические настройки даже при изменении статуса.
create or replace function public.enforce_premium_cosmetics() returns trigger
language plpgsql as $$
begin
  if not new.is_premium and not new.is_owner then
    new.chat_theme := 'default';
    new.avatar_frame := 'none';
    new.profile_effect := 'none';
  end if;
  return new;
end $$;

-- Выдать права только указанному существующему аккаунту.
-- is_owner не добавляется в пользовательский GRANT UPDATE, поэтому
-- обычный клиент не сможет назначить владельцем самого себя.
update public.profiles
set is_owner = true,
    is_premium = true,
    premium_until = null,
    chat_theme = 'aurora',
    avatar_frame = 'gold',
    profile_effect = 'sparkles'
where id = 'e5668300-b9e3-4062-aae4-da32b27003fe'::uuid
returning id, username, is_owner, is_premium, premium_until;

-- В результате UPDATE должна вернуться ровно одна строка.
